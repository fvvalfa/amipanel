from django.apps import AppConfig


class WorkcalendarConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'workcalendar'
    verbose_name = 'Рабочий календарь'